#ifndef IN_HPP
#define IN_HPP

#include "Command.hpp"
class In: public Command{
public:
	In(char i);
	virtual void execute(EditorModel& model);
	virtual void undo(EditorModel& model);
private:
	char i;
};

#endif