#include "in.hpp"


//this class fuction is used to store the character that wants to be added to the text editor
In::In(char i)
:i{i}
{
}

//this function is called when a character is pressed without ctrl
//its purpose is to add a character where the cursor is located

void In::execute(EditorModel& model){
	model.inp(i);
}

//this function is called to delete the character that is added by In::execute
void In::undo(EditorModel& model){
	model.delete_char();
}
