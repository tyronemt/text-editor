#ifndef DELETELINE_HPP
#define DELETELINE_HPP

#include "Command.hpp"
class deleteLine: public Command{
public:
	virtual void execute(EditorModel& model);
	virtual void undo(EditorModel& model);
private:
	unsigned int col;
	unsigned int lne;
    std::string line;
   	std::vector<std::string> vect;
};

#endif