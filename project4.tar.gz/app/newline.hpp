#ifndef NEWLINE_HPP
#define NEWLINE_HPP

#include "Command.hpp"

class newLine: public Command{
	virtual void execute(EditorModel& model);
	virtual void undo(EditorModel& model);
};

#endif