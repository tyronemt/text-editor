#include "deleteLine.hpp"


//this function is called when ctrl + d is pressed
//its purpose is to delete the line the cursor is on
void deleteLine::execute(EditorModel& model){
	col = model.cursorColumn();
	lne = model.cursorLine();
	vect = model.getVector();
	model.delete_line();
}

// this function is called to undo the deleteLine function
void deleteLine::undo(EditorModel& model){
	line = vect.at(lne-1);
	if (vect.size() > 1 and lne == 1){
		model.set_cursor_location(1,1);
		model.newline();
		model.insert_line(lne,line);
	}
	else{
		model.insert_line(lne,line);
	}
	model.set_cursor_location(col,lne);

}
