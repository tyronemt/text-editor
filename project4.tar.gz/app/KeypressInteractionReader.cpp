// KeypressInteractionReader.cpp
//
// ICS 45C Fall 2019
// Project #4: People Just Want to Play with Words
//
// Implementation of the KeypressInteractionReader
//
// YOU WILL NEED TO IMPLEMENT SOME THINGS HERE

#include "KeypressInteractionReader.hpp"
#include "Command.hpp"


#include "movement.hpp"
#include "in.hpp"
#include "newline.hpp"
#include "Interaction.hpp"
#include "deleteChar.hpp"
#include "deleteLine.hpp"



// You will need to update this member function to watch for the right
// keypresses and build the right kinds of Interactions as a result.
//
// The reason you'll need to implement things here is that you'll need
// to create Command objects, which you'll be declaring and defining
// yourself; they haven't been provided already.
//
// I've added handling for "quit" here, but you'll need to add the others.

Interaction KeypressInteractionReader::nextInteraction()
{
    while (true)
    {
        Keypress keypress = keypressReader.nextKeypress();
        
        if (keypress.ctrl())
        {
            // The user pressed a Ctrl key (e.g., Ctrl+X); react accordingly

            switch (keypress.code())
            {
            case 'X':
            {
                return Interaction::quit();
            }
            case 'O':
            {
                Command* comRight = new Right;
                return Interaction::command(comRight);
            }
            case 'I':
            {
                Command* comUp = new Up;
                return Interaction::command(comUp);
            }
            case 'K':
            {
                Command* comDown = new Down;
                return Interaction::command(comDown);
            }
            case 'U':
            {
                Command* comLeft = new Left;
                return Interaction::command(comLeft);
            }
            case 'J':
            {
                Command* comNewLine = new newLine;
                return Interaction::command(comNewLine);
            }
            case 'M':
            {
                Command* comNewLine = new newLine;
                return Interaction::command(comNewLine);
            }
            case 'H':
            {
                Command* comdelete_char = new deleteChar;
                return Interaction::command(comdelete_char);
            }
            case 'Y':
            {
                Command* comHome = new Home;
                return Interaction::command(comHome);
            }
            case 'P':
            {
                Command* comEnd = new End;
                return Interaction::command(comEnd);
            }
            case 'D':
            {
                Command* comdelete_line = new deleteLine;
                return Interaction::command(comdelete_line);
            }
            case 'Z':
            {
                return Interaction::undo();
            }
            case 'A':
            {
                return Interaction::redo();
            }
            }

        }
        else
        {
            Command* comInput = new In(keypress.code());
            return Interaction::command(comInput);
        }
        
    }
}

