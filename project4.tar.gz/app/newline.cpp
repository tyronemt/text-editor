#include "newline.hpp"

//this function is used like an enter key in which it creates a new line when it is clicked 
void newLine::execute(EditorModel& model){
	model.newline();
}

//this function back spaces or delete the previous character 
void newLine::undo(EditorModel& model){
	model.delete_char();
}