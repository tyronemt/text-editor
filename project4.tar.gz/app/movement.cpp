#include "movement.hpp"

//moves the cursor down
void Down::execute(EditorModel& model){
	model.moveDown();
}
//moves the cursor up
void Down::undo(EditorModel& model){
	model.moveUp();
}
//move the cursor left
void Left::execute(EditorModel& model){
	model.moveLeft();
}
//move the cursor right
void Left::undo(EditorModel& model){
	model.moveRight();
}
//move the cursor right
void Right::execute(EditorModel& model){
	model.moveRight();
}
//move the cursor left
void Right::undo(EditorModel& model){
	model.moveLeft();
}
//move the cursor up
void Up::execute(EditorModel& model){
	model.moveUp();
}
//move the cursor down
void Up::undo(EditorModel& model){
	model.moveDown();
}
//move the cursor to the front of the current line
void Home::execute(EditorModel& model){
	col = model.cursorColumn();
	lne = model.cursorLine();
	model.home();
}
//move the cursor back to the original position
void Home::undo(EditorModel& model){
	model.set_cursor_location(col,lne);
}
//move the cursor to the back of the current line
void End::execute(EditorModel& model){
	col = model.cursorColumn();
	lne = model.cursorLine();
	model.end();
}
//move the cursor to the original position
void End::undo(EditorModel& model){
	model.set_cursor_location(col,lne);
}