
#ifndef MOVEMENT_HPP
#define MOVEMENT_HPP

#include "Command.hpp"
class Down: public Command{
virtual void execute(EditorModel& model);
virtual void undo(EditorModel& model);
};

class Left: public Command{
virtual void execute(EditorModel& model);
virtual void undo(EditorModel& model);
};

class Right: public Command{
virtual void execute(EditorModel& model);
virtual void undo(EditorModel& model);
};

class Up: public Command{
virtual void execute(EditorModel& model);
virtual void undo(EditorModel& model);
};

class Home: public Command{
public:
	virtual void execute(EditorModel& model);
	virtual void undo(EditorModel& model);
private:
	unsigned int col;
	unsigned int lne;
};

class End: public Command{
public:
	virtual void execute(EditorModel& model);
	virtual void undo(EditorModel& model);
private:
	unsigned int col;
	unsigned int lne;
};

#endif
