// EditorModel.cpp
//
// ICS 45C Fall 2019
// Project #4: People Just Love to Play with Words
//
// Implementation of the EditorModel class

#include "EditorModel.hpp"
#include "EditorException.hpp"


EditorModel::EditorModel()
	:cursor_line{1},cursor_column{1},error_message{""},vect{""}
{
}


//returns the cursor line
int EditorModel::cursorLine() const
{
    return cursor_line;
}

//returns the cursor column
int EditorModel::cursorColumn() const
{
    return cursor_column;
}

//return the number of strings in the vector
int EditorModel::lineCount() const
{
    return vect.size();
}

//returns a specific line
const std::string& EditorModel::line(int lineNumber) const
{
	return vect.at(lineNumber-1);
}

// returns the error message
const std::string& EditorModel::currentErrorMessage() const
{
    return error_message;
}

// set the error message to a desire error message
void EditorModel::setErrorMessage(const std::string& errorMessage)
{
	error_message = errorMessage;
}

// clear error message
void EditorModel::clearErrorMessage()
{
	if (error_message != ""){
		error_message = "";
	}
}

// lets the fuctions outside of the EditorModel class access the vector
std::vector<std::string> EditorModel::getVector(){
	return vect;
}


//moves the cursor to a specified column and line
void EditorModel::set_cursor_location(unsigned int col, unsigned int lne){
	cursor_column = col;
	cursor_line = lne;
}

//inserts a specific line into the vector 
void EditorModel::insert_line(unsigned int lne,std::string line){
	if (lne != 1){
	vect.insert(vect.begin() + lne-1,line);
	}
	else{
		vect.at(lne-1) = line;
	}
}

//moves the cursor right
void EditorModel::moveRight(){
	if (cursor_column == vect.at(cursor_line-1).length() + 1 and cursor_line == lineCount()){
		throw EditorException("Already at end");
	}
	else if (cursor_column < vect.at(cursor_line-1).length() + 1){
		cursor_column += 1;
	}
	else if(cursor_line < lineCount()){
		cursor_line += 1;
		cursor_column = 1;
	}
}

//moves the cursor up
void EditorModel::moveUp(){
	if (cursor_line == 1){
		throw(EditorException("Already at top"));
	}
	cursor_line -= 1;
	if(cursor_column > vect.at(cursor_line - 1).length() + 1){
		cursor_column = vect.at(cursor_line - 1).length() + 1;
	}
	
}

//moves the cursor down
void EditorModel::moveDown(){
	if (cursor_line == vect.size()){
		throw(EditorException("Already at bottom"));
	}
	cursor_line += 1;
	if(cursor_column > vect.at(cursor_line - 1).length() + 1){
		cursor_column = vect.at(cursor_line - 1).length() + 1;
	}
}

//moves the cursor left
void EditorModel::moveLeft(){
	if (cursor_column == 1 and cursor_line == 1){
		throw EditorException("Already at beginning");
	}
	else if (cursor_column > 1 ){
		cursor_column -= 1;
	}
	else if(cursor_line > 1){
		cursor_line -= 1;
		cursor_column = vect.at(cursor_line-1).length() + 1 ;
	}
}

//inputs a character to the left of the cursor
void EditorModel::inp(char i){
	vect.at(cursor_line-1) = vect.at(cursor_line - 1).insert(cursor_column-1,1,i);
	cursor_column += 1;
}

//works like the enter key which creates a new line from where the cursor is
void EditorModel::newline(){
	std::string new_line;
	new_line = vect.at(cursor_line-1).substr(cursor_column-1);
	vect.at(cursor_line - 1) = vect.at(cursor_line- 1).substr(0,cursor_column - 1);
	vect.insert(vect.begin() + cursor_line, new_line);

	cursor_line += 1;
	cursor_column = 1;

}

//works as backspace which deletes the character to the left of the cursor
void EditorModel::delete_char(){
	if (cursor_column == 1 and cursor_line == 1){
		throw EditorException("Already at beginning");
	}
	else if (cursor_column > 1 ){
		vect.at(cursor_line-1).erase(cursor_column - 2,1);
		cursor_column -= 1;
	}
	else if(cursor_column == 1){
		if (vect.at(cursor_line - 1).length() != 0){
			cursor_line -= 1;
			cursor_column = vect.at(cursor_line-1).length() + 1;
			vect.at(cursor_line - 1) = vect.at(cursor_line-1) + vect.at(cursor_line);
			vect.erase(vect.begin() + cursor_line);
		}
		else{
		vect.erase(vect.begin() + cursor_line - 1);
		cursor_line -= 1;
		cursor_column = vect.at(cursor_line-1).length() + 1; 
		}

	}
}

//places the cursor to the column = 1 position
void EditorModel::home(){
	cursor_column = 1;
}

//places the cursor to the end of the current line
void EditorModel::end(){
	cursor_column = vect.at(cursor_line-1).length() + 1;
}



//deletes the current line
void EditorModel::delete_line(){
	if (vect.size() != 1){
		vect.erase(vect.begin() + cursor_line - 1);
		if (cursor_line - 1 == vect.size()){
			moveUp();
		}
		if (cursor_column > vect.at(cursor_line-1).length() + 1){
			cursor_column = vect.at(cursor_line-1).length() + 1;
		}
		
	}
	else{
		if (vect.at(0).length() != 0){
			vect.at(0) = "";
			cursor_column = 1;
		}
		else{
			throw EditorException("Already empty");
		}
	}

}