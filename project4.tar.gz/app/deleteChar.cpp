#include "deleteChar.hpp"

//this function is called when ctrl + h is pressed
//its purpose is to delete a character to the left of the cursor

void deleteChar::execute(EditorModel& model){

	col = model.cursorColumn();
	lne = model.cursorLine();
	vect = model.getVector();

	model.delete_char();

	if (col != 1){
		Char = vect.at(lne-1).at(col-2);
	}
}

// this function is called to undo the deleteChar::execute function
void deleteChar::undo(EditorModel& model){
	if (col == 1){
		model.newline();
	}
	else{
		model.inp(Char);
	}
}
