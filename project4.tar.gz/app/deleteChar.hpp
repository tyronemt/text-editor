

#ifndef DELETECHAR_HPP
#define DELETECHAR_HPP

#include "Command.hpp"
class deleteChar: public Command{
public:
	virtual void execute(EditorModel& model);
	virtual void undo(EditorModel& model);
private:
	unsigned int col;
	unsigned int lne;
    unsigned int Char;
   	std::vector<std::string> vect;
};

#endif